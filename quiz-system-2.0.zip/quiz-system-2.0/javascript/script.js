const mainContainer = document.querySelector(".main-container");
const quizContainer = document.querySelector(".quiz-container");
const answerOptions = document.querySelector(".answer-options");
const nextQuestionBtn = document.querySelector(".next-question-btn");
const questionStatus = document.querySelector(".question-status");
const timerDisplay = document.querySelector(".time-duration");
const resultContainer = document.querySelector(".result-container");
const authContainer = document.querySelector(".auth-container");
const loginForm = document.querySelector(".login-form");
const signupForm = document.querySelector(".signup-form");
const toggleAuthLinks = document.querySelectorAll(".toggle-auth");

const QUIZ_TIME_LIMIT = 10;
let currentTime = QUIZ_TIME_LIMIT;
let timer = null;
let quizCategory = "programming";
let numberOfQuestions = 5;
let currentQuestion = null;
const questionsIndexHistory = [];
let correctAnswerCount = 0;




// HTML entity decoder
const decodeHTML = html => {
    const txt = document.createElement("textarea");
    txt.innerHTML = html;
    return txt.value;
};

// Shuffle options
const shuffleArray = array => array.sort(() => Math.random() - 0.5);

// Fetch from Open Trivia DB API
const fetchRandomQuestions = async (amount = 5) => {
    const url = `https://opentdb.com/api.php?amount=${amount}&type=multiple`;
    const res = await fetch(url);
    const data = await res.json();

    return data.results.map(q => {
        const decodedQuestion = decodeHTML(q.question);
        const decodedCorrect = decodeHTML(q.correct_answer);
        const decodedOptions = [...q.incorrect_answers.map(decodeHTML), decodedCorrect];
        const shuffled = shuffleArray(decodedOptions);
        return {
            question: decodedQuestion,
            options: shuffled,
            correctAnswer: shuffled.indexOf(decodedCorrect)
        };
    });
};

// Auth toggle
toggleAuthLinks.forEach(link => {
    link.addEventListener("click", () => {
        loginForm.style.display = loginForm.style.display === "none" ? "flex" : "none";
        signupForm.style.display = signupForm.style.display === "none" ? "flex" : "none";
    });
});

// Sign Up
signupForm.addEventListener("submit", e => {
    e.preventDefault();
    const username = document.querySelector(".signup-username").value.trim();
    const password = document.querySelector(".signup-password").value.trim();
    if (!username || !password) return alert("Please enter both username and password.");
    if (localStorage.getItem(username)) {
        alert("Username already exists!");
    } else {
        localStorage.setItem(username, password);
        alert("Signup successful! You can now log in.");
        signupForm.reset();
        loginForm.style.display = "flex";
        signupForm.style.display = "none";
    }
});

// Login
loginForm.addEventListener("submit", e => {
    e.preventDefault();
    const username = document.querySelector(".login-username").value.trim();
    const password = document.querySelector(".login-password").value.trim();
    const storedPassword = localStorage.getItem(username);
    if (storedPassword === password) {
        authContainer.style.display = "none";
        mainContainer.style.display = "block";
    document.getElementById("howToPlay").style.display="none";
    } else {
        alert("Invalid credentials!");
    }
});

// Start Quiz
const startQuiz = async () => {
    quizCategory = mainContainer.querySelector(".category-option.active").textContent.trim().toLowerCase();
    numberOfQuestions = parseInt(mainContainer.querySelector(".question-option.active").textContent);

    if (quizCategory === "random") {
        if (!navigator.onLine) {
            alert("You're offline. Please connect to the internet to use the Random category.");
            return;
        }

        try {
            const res = await fetch(`https://opentdb.com/api.php?amount=${numberOfQuestions}&type=multiple`);
            const data = await res.json();

            window.randomFetchedQuestions = data.results.map(q => {
                const decodedQuestion = decodeHTML(q.question);
                const decodedCorrect = decodeHTML(q.correct_answer);
                const decodedOptions = [...q.incorrect_answers.map(decodeHTML), decodedCorrect];
                const shuffled = shuffleArray(decodedOptions);
                return {
                    question: decodedQuestion,
                    options: shuffled,
                    correctAnswer: shuffled.indexOf(decodedCorrect)
                };
            });
        } catch (err) {
            alert("Failed to fetch random questions. Try again later.");
            return;
        }
    }

    mainContainer.style.display = "none";
    quizContainer.style.display = "block";
    renderQuestion();
};




// Render one question
const renderQuestion = () => {
    currentQuestion = getRandomQuestion();
    if (!currentQuestion) return;

    resetTimer();
    startTimer();

    answerOptions.innerHTML = "";
    nextQuestionBtn.style.visibility = "hidden";
    quizContainer.querySelector(".quiz-timer").style.background = "#32313c";
    document.querySelector(".question-text").textContent = currentQuestion.question;
    questionStatus.innerHTML = ` <b>${questionsIndexHistory.length}</b> of <b>${numberOfQuestions}</b> Question`;

    currentQuestion.options.forEach((option, index) => {
        const li = document.createElement("li");
        li.classList.add("answer-option");
        li.textContent = option;
        answerOptions.appendChild(li);
        li.addEventListener("click", () => handleAnswer(li, index));
    });
};

// Fetch question by category
const getRandomQuestion = () => {
    let categoryQuestions = [];

    if (quizCategory === "random") {
        categoryQuestions = window.randomFetchedQuestions || [];
    } else {
        const selectedCategory = questions.find(cat => cat.category.toLowerCase() === quizCategory);
        categoryQuestions = selectedCategory ? selectedCategory.questions : [];
    }

    if (categoryQuestions.length === 0) {
        alert("No questions available. Please try again.");
        return null;
    }

    if (questionsIndexHistory.length >= Math.min(categoryQuestions.length, numberOfQuestions)) {
        return showQuizResult();
    }

    const availableQuestions = categoryQuestions.filter((_, index) => !questionsIndexHistory.includes(index));
    const randomQuestion = availableQuestions[Math.floor(Math.random() * availableQuestions.length)];

    questionsIndexHistory.push(categoryQuestions.indexOf(randomQuestion));
    return randomQuestion;
};

// Answer handler
const handleAnswer = (option, answerIndex) => {
    clearInterval(timer);

    const isCorrect = currentQuestion.correctAnswer === answerIndex;
    option.classList.add(isCorrect ? 'correct' : 'incorrect');
    !isCorrect ? highlightCorrectAnswer() : correctAnswerCount++;

    if (!option.querySelector(".material-symbols-outlined")) {
        const iconHTML = `<span class="material-symbols-outlined">${isCorrect ? 'check_circle' : 'cancel'}</span>`;
        option.insertAdjacentHTML("beforeend", iconHTML);
    }

    answerOptions.querySelectorAll(".answer-option").forEach(option => {
        option.style.pointerEvents = "none";
    });

    nextQuestionBtn.style.visibility = "visible";
};

// Highlight correct answer
const highlightCorrectAnswer = () => {
    const correctOption = answerOptions.querySelectorAll(".answer-option")[currentQuestion.correctAnswer];
    correctOption.classList.add("correct");

    if (!correctOption.querySelector(".material-symbols-outlined")) {
        const iconHTML = `<span class="material-symbols-outlined">check_circle</span>`;
        correctOption.insertAdjacentHTML("beforeend", iconHTML);
    }
};

// Timer logic
const resetTimer = () => {
    clearInterval(timer);
    currentTime = QUIZ_TIME_LIMIT;
    timerDisplay.textContent = ` ${currentTime}s`;
};
//start timer
const startTimer = () => {
    timer = setInterval(() => {
        currentTime--;
        timerDisplay.textContent = `${currentTime}s`;

        if (currentTime <= 0) {
            clearInterval(timer);
            highlightCorrectAnswer();
            nextQuestionBtn.style.visibility = "visible";
            quizContainer.querySelector(".quiz-timer").style.background = "#c31402";
            answerOptions.querySelectorAll(".answer-option").forEach(option => option.style.pointerEvents = "none");
        }
    }, 1000);
};

// Quiz Result
const showQuizResult = () => {
    quizContainer.style.display = "none";
    resultContainer.style.display = "block";
    const resultText = `You answered <b>${correctAnswerCount}</b> out of <b>${numberOfQuestions}</b> questions correctly. Great Efforts!`;
    document.querySelector(".result-message").innerHTML = resultText;
};

// Reset
const resetQuiz = () => {
    resetTimer();
    correctAnswerCount = 0;
    questionsIndexHistory.length = 0;
    mainContainer.style.display = "block";
    resultContainer.style.display = "none";
};

// Option selection UI
document.querySelectorAll(".category-option, .question-option").forEach(option => {
    option.addEventListener("click", () => {
        option.parentNode.querySelector(".active")?.classList.remove("active");
        option.classList.add("active");
    });
});


// Event Listeners
nextQuestionBtn.addEventListener("click", renderQuestion);
document.querySelector(".try-again-btn").addEventListener("click", resetQuiz);
document.querySelector(".start-quiz-btn").addEventListener("click", startQuiz);

