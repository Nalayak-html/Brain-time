// Array of questions grouped by category (25 questions each)

const questions = [
    {
        category: "programming",
        questions: [
            {
                question: "What does HTML stand for?",
                options: ["Hyper Text Pre Processor", "Hyper Text Markup Language", "Hyper Text Multiple Language", "Hyper Tool Multi Language"],
                correctAnswer: 1,
            },
            {
                question: "Which of the following is a correct way to declare a variable in JavaScript?",
                options: ["var x = 10;", "variable x = 10;", "int x = 10;", "let 10 = x;"],
                correctAnswer: 0,
            },
            {
                question: "How do you write comment in Python?",
                options: ["// This is a comment", "# This is a comment", "/* This is a comment /", "<!-- This is a comment -->"],
                correctAnswer: 1,
            },
            {
                question: "What does CSS stand for?",
                options: ["Cascading Style Sheets", "Colorful Style Sheets", "Computer Style Sheets", "Cascading Simple Sheets"],
                correctAnswer: 0,
            },
            {
                question: "In JavaScript, how do you create a function?",
                options: ["create function myFunction()", "def function myFunction()", "func myFunction()", "function myFunction()"],
                correctAnswer: 3,
            },
            {
                question: "What does the 'typeof' operator do in JavaScript?",
                options: ["Checks the type of a variable", "Declares a variable", "Assigns a value to a variable", "Converts a variable to another type"],
                correctAnswer: 0,
            },
            {
                question: "In C, how do you define a function?",
                options: ["function myFunction()", "def myFunction()", "void myFunction()", "func myFunction()"],
                correctAnswer: 2,
            },
            {
                question: "Which of the following is a characteristic of Python?",
                options: ["Compiled language", "Dynamic typing", "Low-level language", "Static typing"],
                correctAnswer: 3,
            },
            {
                question: "Which language is used for Android development?",
                options: ["Python", "Java", "JavaScript", "C++"],
                correctAnswer: 1,
            },
            {
                question: "What is the purpose of the 'forEach()' method in JavaScript?",
                options: ["Removes duplicate elements from an array", "Filters elements in an array", "Sorts an array", "Iterates through each element in an array"],
                correctAnswer: 3,
            },
            {
                question: "What does the 'return' keyword do in a function?",
                options: ["Ends the function and returns a value", "Continues the function", "Exits the function without value", "Ends the program execution"],
                correctAnswer: 0,
            },
            {
                question: "Which of the following is NOT a semantic HTML element?",
                options: ["<header>", "<footer>", "<div>", "<article>"],
                correctAnswer: 2,
            },
            {
                question: "What is the primary purpose of a 'for' loop in programming?",
                options: ["Repeat code for a specified number of times", "Repeat code until a condition is true", "Define a function", "Evaluate conditions in the loop"],
                correctAnswer: 0,
            },
            {
                question: "Which data structure is ideal for LIFO (Last In First Out)?",
                options: ["Queue", "Stack", "Linked list", "Array"],
                correctAnswer: 1,
            },
            {
                question: "Which command is used in Git to store changes in the repository?",
                options: ["git commit", "git push", "git pull", "git add"],
                correctAnswer: 0,
            },
            {
                question: "What does the 'map()' function do in JavaScript?",
                options: ["Sorts an array", "Filters out items", "Creates a new array", "Modifies the original array"],
                correctAnswer: 2,
            },
            {
                question: "What is an IDE?",
                options: ["An Integrated Development Environment", "A function for code execution", "An interpreter", "An input method for writing code"],
                correctAnswer: 0,
            },
            {
                question: "Which of the following is a feature of object-oriented programming?",
                options: ["Encapsulation", "Modularity", "Recursion", "Memory Management"],
                correctAnswer: 0,
            },
            {
                question: "What does SQL stand for?",
                options: ["Simple Question Language", "Systematic Query Language", "Standard Question Language", "Structured Query Language"],
                correctAnswer: 3,
            },
            {
                question: "Which of these is an example of a non-relational database?",
                options: ["MongoDB", "MySQL", "PostgreSQL", "Oracle"],
                correctAnswer: 0,
            },
            {
                question: "How do you write comment in CSS?",
                options: ["// This is a comment", "/ This is a comment */", "# This is a comment", "<!-- This is a comment -->"],
                correctAnswer: 1,
            },
            {
                question: "Which of the following algorithms is used to sort an array by comparing elements?",
                options: ["Bubble sort", "Insertion sort", "Quick sort", "Merge sort"],
                correctAnswer: 0,
            },
            {
                question: "What does the 'finally' block in Java do?",
                options: ["Handles all exceptions", "Attempts to handle runtime exceptions", "Executes code after try-catch", "Defines execution start point"],
                correctAnswer: 2,
            },
            {
                question: "Which data structure is best for searching elements quickly?",
                options: ["Binary search tree", "Array", "Linked list", "Queue"],
                correctAnswer: 0,
            },
            {
                question: "What is the correct syntax for a JavaScript if statement?",
                options: ["if (condition) {}", "if condition {}", "if {} else", "if {condition}"],
                correctAnswer: 0,
            },
        ],
    },

    {
        category: "Anime/Manga",
        questions: [
            {
                question: "In 'Hunter x Hunter', what is the name of the Nen category Kurapika uses with his Scarlet Eyes?",
                options: ["Enhancer", "Emitter", "Conjurer", "Specialist"],
                correctAnswer: 3,
            },
            {
                question: "Which manga holds the Guinness World Record for 'Most Published Comic Series by a Single Author'?",
                options: ["One Piece", "Detective Conan", "KochiKame", "Golgo 13"],
                correctAnswer: 2,
            },
            {
                question: "What is the hidden meaning behind the title 'Tokyo Revengers'?",
                options: ["It refers to gang rivalry in Tokyo", "It's a mistranslation", "It symbolizes time travel revenge", "It refers to a real historical event"],
                correctAnswer: 2,
            },
            {
                question: "In the anime 'Made in Abyss', what is the name of the deepest known layer of the Abyss?",
                options: ["The Capital of the Unreturned", "The Sea of Corpses", "The Final Maelstrom", "The Deepest Point"],
                correctAnswer: 0,
            },
            {
                question: "In the manga 'Berserk', what is the name of the group led by Griffith?",
                options: ["Band of the Falcon", "Knights of the Eclipse", "Black Swordsmen", "Midland Army"],
                correctAnswer: 0,
            },
            {
                question: "What is the source of the powers in 'Jujutsu Kaisen'?",
                options: ["Cursed Energy", "Spiritual Qi", "Demon Contracts", "Bloodline Techniques"],
                correctAnswer: 0,
            },
            {
                question: "Which manga series was inspired by the author's experience playing volleyball in school?",
                options: ["Blue Lock", "Haikyuu!!", "Kuroko no Basket", "Ace of Diamond"],
                correctAnswer: 1,
            },
            {
                question: "Which studio is known for animating 'Mob Psycho 100' and 'One Punch Man' Season 1?",
                options: ["MAPPA", "Ufotable", "Studio Bones", "Madhouse"],
                correctAnswer: 3,
            },
            {
                question: "Which anime features characters ranked by power into 'God Tiers', such as 'S-Class Rank 1'?",
                options: ["My Hero Academia", "Bleach", "One Punch Man", "Mob Psycho 100"],
                correctAnswer: 2,
            },
            {
                question: "In 'Parasyte: The Maxim', what is the name the protagonist gives to the parasite in his right hand?",
                options: ["Migi", "Hiro", "Kisei", "Ten"],
                correctAnswer: 0,
            },
            {
                question: "Which anime features the Phantom Troupe?",
                options: ["One Piece", "Bleach", "Hunter x Hunter", "Fairy Tail"],
                correctAnswer: 2,
            },
            {
                question: "Who is the captain of the Straw Hat Pirates?",
                options: ["Zoro", "Sanji", "Luffy", "Ace"],
                correctAnswer: 2,
            },
            {
                question: "Which island is the final destination in 'One Piece'?",
                options: ["Skypiea", "Raftel", "Sabaody", "Wano"],
                correctAnswer: 1,
            },
            {
                question: "What is the capital of the Hidden Leaf Village in 'Naruto'?",
                options: ["Sunagakure", "Kumogakure", "Konoha", "Kirigakure"],
                correctAnswer: 2,
            },
            {
                question: "Which anime character has the most transformations?",
                options: ["Ichigo", "Naruto", "Goku", "Natsu"],
                correctAnswer: 2,
            },
            {
                question: "Which anime features a tower and irregulars?",
                options: ["Tower of God", "Sword Art Online", "Bleach", "Blue Exorcist"],
                correctAnswer: 0,
            },
            {
                question: "Which anime is set in a post-apocalyptic Tokyo with ghouls?",
                options: ["Tokyo Revengers", "Tokyo Ghoul", "Parasyte", "Devilman Crybaby"],
                correctAnswer: 1,
            },
            {
                question: "In which anime does Edward Elric appear?",
                options: ["Bleach", "Fullmetal Alchemist", "Fairy Tail", "Code Geass"],
                correctAnswer: 1,
            },
            {
                question: "Which anime is famous for the phrase 'Plus Ultra'?",
                options: ["Attack on Titan", "My Hero Academia", "Fire Force", "Dr. Stone"],
                correctAnswer: 1,
            },
            {
                question: "What is the capital city in 'Code Geass'?",
                options: ["Ashford", "Pendragon", "Area 11", "Shinjuku"],
                correctAnswer: 1,
            },
            {
                question: "Which anime's original language is Japanese?",
                options: ["Avatar", "Teen Titans", "Naruto", "Ben 10"],
                correctAnswer: 2,
            },
            {
                question: "Which anime character is known for his volcano-based powers?",
                options: ["Ace", "Endeavor", "Agni", "Roy Mustang"],
                correctAnswer: 1,
            },
            {
                question: "Which anime city is called 'Neo-Tokyo'?",
                options: ["Evangelion", "Tokyo Ghoul", "Akira", "Gantz"],
                correctAnswer: 2,
            },
            {
                question: "Which anime features an ocean called the 'Calm Belt'?",
                options: ["Fairy Tail", "Black Clover", "One Piece", "Bleach"],
                correctAnswer: 2,
            },
            {
                question: "Which anime has the second largest number of episodes after 'One Piece'?",
                options: ["Bleach", "Naruto", "Detective Conan", "Dragon Ball"],
                correctAnswer: 2,
            },
        ],
    },

    {
        category: "sports",
        questions: [
            {
                question: "Which team won the ICC Champions Trophy 2025?",
                options: ["India", "Australia", "New Zealand", "South Africa"],
                correctAnswer: 0,
            },
            {
                question: "Who was named Player of the Tournament in the ICC Champions Trophy 2025?",
                options: ["Virat Kohli", "Rachin Ravindra", "Josh Inglis", "Rohit Sharma"],
                correctAnswer: 1,
            },
            {
                question: "Which venue hosted the final of the ICC Champions Trophy 2025?",
                options: ["Gaddafi Stadium, Lahore", "Dubai International Cricket Stadium", "Eden Gardens, Kolkata", "Melbourne Cricket Ground"],
                correctAnswer: 1,
            },
            {
                question: "Which team chased the highest total successfully in the ICC Champions Trophy 2025?",
                options: ["India", "Australia", "New Zealand", "South Africa"],
                correctAnswer: 1,
            },
            {
                question: "Who scored the fastest century in the ICC Champions Trophy 2025?",
                options: ["Ben Duckett", "Josh Inglis", "Rachin Ravindra", "Virat Kohli"],
                correctAnswer: 1,
            },
            {
                question: "Which team did Afghanistan defeat for the first time in ICC Champions Trophy history during the 2025 tournament?",
                options: ["England", "Australia", "South Africa", "Pakistan"],
                correctAnswer: 0,
            },
            {
                question: "Who was the leading wicket-taker in the ICC Champions Trophy 2025?",
                options: ["Mohammad Shami", "Kagiso Rabada", "Trent Boult", "Pat Cummins"],
                correctAnswer: 0,
            },
            {
                question: "Which player achieved the milestone of 14,000 ODI runs during the ICC Champions Trophy 2025?",
                options: ["Virat Kohli", "Rohit Sharma", "Kane Williamson", "Joe Root"],
                correctAnswer: 0,
            },
            {
                question: "Which country won the ICC Under-19 Women’s T20 World Cup 2025?",
                options: ["India", "England", "Australia", "South Africa"],
                correctAnswer: 0,
            },
            {
                question: "Which team achieved a record-breaking 665/5 declared against Surrey in the 2025 County Championship?",
                options: ["Yorkshire", "Warwickshire", "Lancashire", "Nottinghamshire"],
                correctAnswer: 1,
            },
            {
                question: "What unprecedented tactic did the UAE women's cricket team employ during their T20 match against Qatar in May 2025?",
                options: [
                    "Declared their innings early",
                    "Retired all 10 batters without facing a ball",
                    "Played with only 9 players",
                    "Used substitute fielders for the entire match"
                ],
                correctAnswer: 1,
            },
            {
                question: "Which English county team secured a 366-run victory over Hampshire in May 2025?",
                options: ["Yorkshire", "Nottinghamshire", "Essex", "Sussex"],
                correctAnswer: 1,
            },
            {
                question: "Which Indian player climbed to the 5th spot in the ICC Women's All-Rounders Rankings in March 2025?",
                options: ["Harmanpreet Kaur", "Deepti Sharma", "Mithali Raj", "Smriti Mandhana"],
                correctAnswer: 1,
            },
            {
                question: "Which Australian cricketer announced retirement from One-Day Internationals in March 2025?",
                options: ["David Warner", "Steve Smith", "Pat Cummins", "Aaron Finch"],
                correctAnswer: 1,
            },
            {
                question: "Which team scored the highest total in a single innings during the ICC Champions Trophy 2025?",
                options: ["England", "Australia", "South Africa", "Afghanistan"],
                correctAnswer: 1,
            },

            // Football (5 Questions)
            {
                question: "Which player announced his departure from Bayern Munich to join AS Monaco after the 2024-2025 season?",
                options: ["Thomas Müller", "Eric Dier", "Leroy Sané", "Harry Kane"],
                correctAnswer: 1,
            },
            {
                question: "What action did Nashville SC's supporters group take in response to immigration arrests in May 2025?",
                options: [
                    "Organized a stadium protest",
                    "Canceled game-day events and boycotted a match",
                    "Released a public statement supporting ICE operations",
                    "Held a fundraising event for affected families"
                ],
                correctAnswer: 1,
            },
            {
                question: "Which major football tournament is scheduled to take place in the USA from June 15 to July 13, 2025?",
                options: [
                    "UEFA Euro 2025",
                    "Copa América 2025",
                    "FIFA Club World Cup 2025",
                    "CONCACAF Gold Cup 2025"
                ],
                correctAnswer: 2,
            },
            {
                question: "Which team secured promotion to the Bundesliga in May 2025?",
                options: ["Hamburg", "Stuttgart", "Werder Bremen", "Schalke 04"],
                correctAnswer: 0,
            },
            {
                question: "Which Premier League team was vying for a Champions League position despite key injuries in May 2025?",
                options: ["Newcastle United", "Chelsea", "Liverpool", "Arsenal"],
                correctAnswer: 0,
            },

            // Chess (5 Questions)
            {
                question: "Who won the 2024 World Chess Championship, becoming the youngest undisputed world chess champion at the age of 18?",
                options: ["Magnus Carlsen", "Ding Liren", "Gukesh Dommaraju", "Ian Nepomniachtchi"],
                correctAnswer: 2,
            },
            {
                question: "Who won the Women's World Chess Championship 2025?",
                options: ["Ju Wenjun", "Tan Zhongyi", "Hou Yifan", "Koneru Humpy"],
                correctAnswer: 0,
            },
            {
                question: "Which team won the Global Chess League 2024?",
                options: ["PBG Alaskan Knights", "Triveni Continental Kings", "Ganges Grandmasters", "American Gambits"],
                correctAnswer: 1,
            },
            {
                question: "Who won the Masters section of the Tata Steel Chess Tournament 2024?",
                options: ["Anish Giri", "Wei Yi", "Gukesh Dommaraju", "Nodirbek Abdusattorov"],
                correctAnswer: 1,
            },
            {
                question: "Who was named Player of the Season in the Global Chess League 2024?",
                options: ["Alexandra Kosteniuk", "Nihal Sarin", "Alireza Firouzja", "Anish Giri"],
                correctAnswer: 1,
            },
        ],
    },

    {
        category: "entertainment",
        questions: [
            {
                question: "Who won the Academy Award for Best Actor in 2022?",
                options: ["Leonardo DiCaprio", "Will Smith", "Joaquin Phoenix", "Matthew McConaughey"],
                correctAnswer: 1,
            },
            {
                question: "Which movie won the Academy Award for Best Picture in 2021?",
                options: ["Parasite", "1917", "The Shape of Water", "Nomadland"],
                correctAnswer: 3,
            },
            {
                question: "Who played the character of Jack Dawson in the movie Titanic?",
                options: ["Leonardo DiCaprio", "Brad Pitt", "Johnny Depp", "Tom Hanks"],
                correctAnswer: 0,
            },
            {
                question: "Which TV show featured the characters Daenerys Targaryen and Jon Snow?",
                options: ["Breaking Bad", "Game of Thrones", "The Witcher", "Vikings"],
                correctAnswer: 1,
            },
            {
                question: "Who is known as the 'King of Pop'?",
                options: ["Michael Jackson", "Prince", "Whitney Houston", "Elvis Presley"],
                correctAnswer: 0,
            },
            {
                question: "Which superhero is known for saying, 'I am Iron Man'?",
                options: ["Black Panther", "Captain America", "Thor", "Iron Man"],
                correctAnswer: 3,
            },
            {
                question: "Which movie franchise includes a character named Luke Skywalker?",
                options: ["Guardians of the Galaxy", "Star Wars", "The Matrix", "Star Trek"],
                correctAnswer: 1,
            },
            {
                question: "Who played the character of Hermione Granger in the Harry Potter film series?",
                options: ["Emma Watson", "Anne Hathaway", "Maggie Smith", "Natalie Portman"],
                correctAnswer: 0,
            },
            {
                question: "Who directed the movie 'Inception'?",
                options: ["James Cameron", "Steven Spielberg", "Christopher Nolan", "Martin Scorsese"],
                correctAnswer: 2,
            },
            {
                question: "Which artist released the album 'Lover' in 2019?",
                options: ["Billie Eilish", "Taylor Swift", "Ed Sheeran", "Ariana Grande"],
                correctAnswer: 1,
            },
            {
                question: "What was the first video game to feature Mario?",
                options: ["Mario Kart", "Super Mario Bros.", "Donkey Kong", "The Legend of Zelda"],
                correctAnswer: 2,
            },
            {
                question: "Which movie features the famous line, 'Here's looking at you, kid'?",
                options: ["Casablanca", "Citizen Kane", "The Godfather", "Gone with the Wind"],
                correctAnswer: 0,
            },
            {
                question: "Which country won the FIFA World Cup in 2018?",
                options: ["France", "Germany", "Argentina", "Brazil"],
                correctAnswer: 0,
            },
            {
                question: "Who created the comic book character Spider-Man?",
                options: ["Jack Kirby", "Stan Lee", "Steve Ditko", "John Romita"],
                correctAnswer: 1,
            },
            {
                question: "In which movie did Heath Ledger portray the Joker?",
                options: ["The Dark Knight", "Batman Begins", "The Dark Knight Rises", "Joker"],
                correctAnswer: 0,
            },
            {
                question: "Which band is known for the hit song 'Bohemian Rhapsody'?",
                options: ["The Rolling Stones", "Led Zeppelin", "Queen", "The Beatles"],
                correctAnswer: 2,
            },
            {
                question: "Which actress starred as Katniss Everdeen in 'The Hunger Games'?",
                options: ["Kristen Stewart", "Shailene Woodley", "Jennifer Lawrence", "Emma Stone"],
                correctAnswer: 2,
            },
            {
                question: "Who played the role of the Joker in the 2019 movie 'Joker'?",
                options: ["Heath Ledger", "Johnny Depp", "Joaquin Phoenix", "Jared Leto"],
                correctAnswer: 2,
            },
            {
                question: "Which Disney animated film features the song 'A Whole New World'?",
                options: ["Cinderella", "Aladdin", "Beauty and the Beast", "The Little Mermaid"],
                correctAnswer: 1,
            },
            {
                question: "Which TV series features the characters of Walter White and Jesse Pinkman?",
                options: ["Narcos", "Better Call Saul", "The Sopranos", "Breaking Bad"],
                correctAnswer: 3,
            },
            {
                question: "Who sang the hit song 'Shape of You'?",
                options: ["Justin Bieber", "Ariana Grande", "Sam Smith", "Ed Sheeran"],
                correctAnswer: 3,
            },
            {
                question: "Which film won the Academy Award for Best Picture in 2020?",
                options: ["The Irishman", "Once Upon a Time in Hollywood", "Parasite", "1917"],
                correctAnswer: 2,
            },
            {
                question: "What year did the movie 'The Matrix' release?",
                options: ["1997", "1998", "2000", "1999"],
                correctAnswer: 3,
            },
            {
                question: "Which actor played Tony Stark/Iron Man in the Marvel Cinematic Universe?",
                options: ["Mark Ruffalo", "Chris Evans", "Robert Downey Jr.", "Chris Hemsworth"],
                correctAnswer: 2,
            },
            {
                question: "Which singer is known as the 'Queen of Pop'?",
                options: ["Mariah Carey", "Lady Gaga", "Whitney Houston", "Madonna"],
                correctAnswer: 3,
            },
        ],
    },
];
